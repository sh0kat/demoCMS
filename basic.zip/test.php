<?php
echo "http://" . $_SERVER['HTTP_HOST']

?>